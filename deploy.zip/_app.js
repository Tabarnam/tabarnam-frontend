let azureApp = null;

try {
  ({ app: azureApp } = require("@azure/functions"));
} catch {
  azureApp = null;
}

const ROUTES_KEY = "__tabarnam_http_registrations";
const TRIGGERS_KEY = "__tabarnam_trigger_registrations";
const PATCHED_KEY = "__tabarnam_http_patched";

const fallbackRegistrations = [];
const fallbackTriggers = [];

function normalizeRoute(value) {
  return String(value || "")
    .trim()
    .replace(/^\//, "")
    .toLowerCase();
}

function getRegistrations() {
  if (azureApp) {
    if (!Array.isArray(azureApp[ROUTES_KEY])) azureApp[ROUTES_KEY] = [];
    return azureApp[ROUTES_KEY];
  }
  return fallbackRegistrations;
}

function getTriggers() {
  if (azureApp) {
    if (!Array.isArray(azureApp[TRIGGERS_KEY])) azureApp[TRIGGERS_KEY] = [];
    return azureApp[TRIGGERS_KEY];
  }
  return fallbackTriggers;
}

function ensurePatched() {
  if (!azureApp) return;
  if (azureApp[PATCHED_KEY]) return;

  const registrations = getRegistrations();
  const triggers = getTriggers();
  const originalHttp = typeof azureApp.http === "function" ? azureApp.http.bind(azureApp) : null;
  const originalStorageQueue = typeof azureApp.storageQueue === "function" ? azureApp.storageQueue.bind(azureApp) : null;

  azureApp.http = (name, opts) => {
    registrations.push({ name, ...(opts || {}) });
    return originalHttp ? originalHttp(name, opts) : undefined;
  };

  azureApp.storageQueue = (name, opts) => {
    triggers.push({ name, type: "storageQueue", ...(opts || {}) });
    return originalStorageQueue ? originalStorageQueue(name, opts) : undefined;
  };

  azureApp[PATCHED_KEY] = true;
}

ensurePatched();

const app =
  azureApp ||
  ({
    http: (name, opts) => {
      getRegistrations().push({ name, ...(opts || {}) });
    },
    storageQueue: (name, opts) => {
      getTriggers().push({ name, type: "storageQueue", ...(opts || {}) });
    },
  });

function listRoutes() {
  return getRegistrations()
    .map((r) => (r && typeof r === "object" ? r.route : ""))
    .map((r) => String(r || "").trim())
    .filter(Boolean);
}

function hasRoute(route) {
  const target = normalizeRoute(route);
  if (!target) return false;
  return getRegistrations().some((r) => normalizeRoute(r?.route) === target);
}

function listHttpRegistrations() {
  return getRegistrations().map((r) => ({
    name: String(r?.name || ""),
    route: String(r?.route || ""),
    methods: Array.isArray(r?.methods) ? [...r.methods] : undefined,
  }));
}

function listTriggers() {
  return getTriggers().map((t) => ({
    name: String(t?.name || ""),
    type: String(t?.type || ""),
    queueName: String(t?.queueName || ""),
  }));
}

function hasTrigger(name) {
  const target = String(name || "").trim().toLowerCase();
  if (!target) return false;
  return getTriggers().some((t) => String(t?.name || "").trim().toLowerCase() === target);
}

if (!app._test) app._test = {};
app._test.listRoutes = listRoutes;
app._test.listHttpRegistrations = listHttpRegistrations;
app._test.hasRoute = hasRoute;
app._test.listTriggers = listTriggers;
app._test.hasTrigger = hasTrigger;

module.exports = { app, hasRoute, listRoutes, listHttpRegistrations, hasTrigger, listTriggers };
