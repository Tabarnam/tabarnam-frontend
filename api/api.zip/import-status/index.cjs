module.exports = async function (context, req) {
  if ((req.method || '').toUpperCase() === 'OPTIONS') {
    context.res = { status: 204, headers: cors(req) }; return;
  }
  const url = (req.query && req.query.url) ? decodeURIComponent(req.query.url) : '';
  if (!url) {
    context.res = { status: 400, headers: cors(req), body: 'Missing ?url=' };
    return;
  }
  const r = await fetch(url);
  const text = await r.text();
  let data; try { data = JSON.parse(text); } catch { data = { raw: text }; }
  context.res = {
    status: r.status,
    headers: { ...cors(req), 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  };
};
function cors(req) {
  const h = req.headers || {};
  const origin = h.origin || h.Origin || '*';
  return {
    'Access-Control-Allow-Origin': origin,
    'Vary': 'Origin',
    'Access-Control-Allow-Methods': 'GET,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization'
  };
}
