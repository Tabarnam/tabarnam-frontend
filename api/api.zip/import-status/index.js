// api/import-status/index.js
import { app } from "@azure/functions";

const cors = (req) => {
  const origin = req.headers.get("origin") || "*";
  return {
    "Access-Control-Allow-Origin": origin,
    Vary: "Origin",
    "Access-Control-Allow-Methods": "GET, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
  };
};
const json = (obj, status = 200, req) => ({
  status,
  headers: { ...cors(req), "Content-Type": "application/json" },
  body: JSON.stringify(obj),
});

app.http("importStatus", {
  route: "import/status",
  methods: ["GET", "OPTIONS"],
  authLevel: "anonymous",
  handler: async (req, ctx) => {
    if (req.method === "OPTIONS") return { status: 204, headers: cors(req) };

    const urlParam = new URL(req.url).searchParams.get("url");
    if (!urlParam) return json({ error: "url query param required" }, 400, req);

    let statusUrl;
    try {
      statusUrl = decodeURIComponent(urlParam);
      const u = new URL(statusUrl);
      if (!u.protocol.startsWith("http")) throw new Error("bad url");
    } catch {
      return json({ error: "invalid status url" }, 400, req);
    }

    try {
      const r = await fetch(statusUrl, { method: "GET" });
      const data = await r.json().catch(() => ({}));
      return json({ ok: true, ...data }, r.status, req);
    } catch (e) {
      return json({ error: "Failed to fetch durable status", detail: String(e) }, 502, req);
    }
  },
});
