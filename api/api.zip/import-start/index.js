// api/import-start/index.js
import { app } from "@azure/functions";

const cors = (req) => {
  const origin = req.headers.get("origin") || "*";
  return {
    "Access-Control-Allow-Origin": origin,
    Vary: "Origin",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
  };
};
const json = (obj, status = 200, req) => ({
  status,
  headers: { ...cors(req), "Content-Type": "application/json" },
  body: JSON.stringify(obj),
});
const text = (body, status = 200, req) => ({
  status,
  headers: { ...cors(req), "Content-Type": "text/plain" },
  body,
});

app.http("importStart", {
  route: "import/start",
  methods: ["GET", "POST", "OPTIONS"],
  authLevel: "anonymous",
  handler: async (req, ctx) => {
    if (req.method === "OPTIONS") return { status: 204, headers: cors(req) };

    const DURABLE_START_URL  = (process.env.DURABLE_START_URL || "").trim();
    const DURABLE_START_CODE = (process.env.DURABLE_START_CODE || "").trim();
    const FUNCTION_URL       = (process.env.FUNCTION_URL || "").trim();
    const FUNCTION_KEY       = (process.env.FUNCTION_KEY || "").trim();

    if (req.method === "GET") {
      // Quick debug
      return json({
        ok: true,
        route: "/api/import/start",
        configured: {
          DURABLE_START_URL: !!DURABLE_START_URL,
          DURABLE_START_CODE: !!DURABLE_START_CODE,
          FUNCTION_URL: !!FUNCTION_URL,
          FUNCTION_KEY: !!FUNCTION_KEY,
        },
        now: new Date().toISOString(),
      }, 200, req);
    }

    if (!DURABLE_START_URL || !DURABLE_START_CODE) {
      return json({ error: "Durable start not configured" }, 500, req);
    }

    let body = {};
    try { body = await req.json(); } catch {}
    // pass-through of user request payload to Durable HttpStart
    const startUrl = new URL(DURABLE_START_URL);
    startUrl.searchParams.set("code", DURABLE_START_CODE);

    try {
      const r = await fetch(startUrl.toString(), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body || {}),
        // Durable starter should respond quickly
      });
      const txt = await r.text();
      // Durable starter often returns a management payload (JSON)
      try {
        const data = JSON.parse(txt);
        return json(data, r.status, req);
      } catch {
        // If not JSON, return as text for easier troubleshooting
        return text(txt, r.status, req);
      }
    } catch (e) {
      return json({ error: "Failed to call Durable starter", detail: String(e) }, 502, req);
    }
  },
});
