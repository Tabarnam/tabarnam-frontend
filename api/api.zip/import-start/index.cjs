const { URL } = require('url');

module.exports = async function (context, req) {
  if ((req.method || '').toUpperCase() === 'OPTIONS') {
    context.res = { status: 204, headers: cors(req) }; return;
  }
  const START_URL  = (process.env.DURABLE_START_URL  || '').trim();
  const START_CODE = (process.env.DURABLE_START_CODE || '').trim();

  if ((req.method || '').toUpperCase() === 'GET') {
    context.res = {
      headers: { ...cors(req), 'Content-Type': 'application/json' },
      body: JSON.stringify({ ok: true, hasUrl: !!START_URL, hasCode: !!START_CODE })
    };
    return;
  }

  if (!START_URL || !START_CODE) {
    context.res = { status: 500, headers: cors(req),
      body: 'Durable not configured (DURABLE_START_URL / DURABLE_START_CODE).' };
    return;
  }

  let payload = {};
  try { payload = req.body || {}; } catch {}

  const u = new URL(START_URL);
  u.searchParams.set('code', START_CODE);

  const r = await fetch(u, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });

  const text = await r.text();
  let data; try { data = JSON.parse(text); } catch { data = { raw: text }; }

  context.res = {
    status: r.status,
    headers: { ...cors(req), 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  };
};

function cors(req) {
  const h = req.headers || {};
  const origin = h.origin || h.Origin || '*';
  return {
    'Access-Control-Allow-Origin': origin,
    'Vary': 'Origin',
    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization'
  };
}
